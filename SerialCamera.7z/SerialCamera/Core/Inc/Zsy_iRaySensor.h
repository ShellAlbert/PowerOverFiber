/*
 * Zsy_iRaySensor.h
 *
 *  Created on: Dec 13, 2022
 *      Author: Administrator
 */

#ifndef INC_ZSY_IRAYSENSOR_H_
#define INC_ZSY_IRAYSENSOR_H_


extern void Zsy_iRaySensorInit(void);

#endif /* INC_ZSY_IRAYSENSOR_H_ */
